# Backend

This directory will contain the FastAPI application.